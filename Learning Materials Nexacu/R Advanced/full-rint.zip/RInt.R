
# Vectorisation
x <- 1:10 + 5
y <- ifelse(x > 10, "big", "small")


# Print object
x <- 1:10
x
print(x)

mtcars$mpg
print(mtcars$mpg, digits = 2)

(x <- 1:10)

cat("result of x", x)

# with()
lin_mod <- lm(Petal.Length ~ Petal.Width, data = iris)

# creates an error
plot(Petal.Width, Petal.Length, data = iris)

plot(iris$Petal.Width, iris$Petal.Length)

with(iris, plot(Petal.Width, Petal.Length))

with(iris, 
     {
       plot(Petal.Width, Petal.Length, col = Species)
       legend("topleft", legend = levels(Species),
              fill = unique(Species))
       abline(lin_mod)
     }
)


# compare with() and within()
iris2 <- within(iris, Petal_Ratio <- Petal.Width / 
                  Petal.Length)

iris3 <- with(iris, Petal_Ratio <- Petal.Width / Petal.Length)


# Inserting multiple quotation marks
library(Hmisc)
Cs(sepal.length, sepal.width, petal.length, 
   petal.width, species, petal.ratio)

names(iris2) <- Cs(sepal.length, sepal.width, petal.length, 
                   petal.width, species, petal.ratio)

# Functions
metricFuel <- function(mpg) {
  mpg / 3.785 * 1.609
}

metricFuel(mtcars$mpg)

metricTon <- function(wt) {
  wt / 2.205
}


# More complex functions

isEfficientmpg <- function(mpg, cutoffkmL = 8){
  kmL <- metricFuel(mpg)
  cat(round(kmL,2), "km/L")
  ifelse(kmL < cutoffkmL, "inefficient", "efficient")
}


isEfficientmpg(mpg = mtcars$mpg)

# Pass arguments to other functions
multiplot <- function(fileName, ...){
  thisFile <- read.csv(fileName)
  x <- as.numeric(thisFile$Paid)
  opar <- par(mfrow = c(1,1), 
              mar = c(5.1, 4.1, 4.1, 2.1), cex.main = 0.8)
  par(mfrow = c(2,1), mar = c(5,4,2,1))
  hist(x, ..., main = "Amount Paid")
  z <- boxplot(x, horizontal = TRUE, ..., main = "Amount Paid")
  par(opar)
  write.csv(z$stats, paste0("BoxplotOutput", fileName, 
                            ".csv"))
  return(z)
}

multiplot("SalesData.csv")

multiplot("SalesData.csv", col = 3, 
          xlab = "Values")


# make changes to save plot
multiplot <- function(fileName, ...){
  thisFile <- read.csv(fileName)
  x <- as.numeric(thisFile$Paid)
  opar <- par(mfrow = c(1,1), 
              mar = c(5.1, 4.1, 4.1, 2.1), cex.main = 0.8)
  bmp(paste0("Distn", fileName, ".bmp"))
  par(mfrow = c(2,1), mar = c(5,4,2,1))
  hist(x, ..., main = "Amount Paid")
  z <- boxplot(x, horizontal = TRUE, ... , 
               main = "Amount Paid")
  dev.off()
  par(opar)
  write.csv(z$stats, paste0("BoxplotOutput", fileName))
  return(z)
}

# Scope and lazy evaluation
isEfficientmpg2 <- function(mpg){
  kmL <- metricFuel(mpg)
  print(paste(round(kmL,2), "km/L"))
  ifelse(kmL < cutoffkmL, "inefficient", "efficient")
}

# will cause an error
isEfficientmpg2(1)

cutoffkmL <- 1

# lexical scoping
isEfficientmpg2(1)


# if and if else
x <- 5:15
ifelse(x > 10, "big", "small") 

x <- 1:10
(xx <- if(x<5) { x + 1 })

xx2 <- vector(mode = "integer", length = length(x))
for( i in 1: length(x) ) if(x[i] < 5) {xx2[i] <- x[i] + 1}

xx3 <- ifelse( x<5, x + 1, 0)

# function with if statement
plot_dist <- function(var){
  if(length(var) < 50) {
    boxplot(var, horiz = TRUE, 
            main = paste(deparse(substitute(var)),
                         "distribution"))
  } else {
    hist(var,
         main = paste(deparse(substitute(var)),
                      "distribution"))
  }
}

plot_dist(mtcars$mpg)
plot_dist(iris$Sepal.Length)


# for loops
for (i in 1: 11) { boxplot(mtcars[, i]) }

for (i in 1: 11) { print(boxplot(mtcars[, i])$stats) }

bxp <- for (i in 1: 11) { print(boxplot(mtcars[, i])$stats) }
bxp

# Save results from a loop
bxp_list <- vector(mode = "list", length = 11)
for (i in 1: 11) { 
  bpres <- (boxplot(mtcars[, i])$stats)
  print(bpres)
  bxp_list[[i]] <- bpres 
}

bpres
i

rm(bpres)
rm(i)

# Wrap in a local() function
bxp_list <- vector(mode = "list", length = 11)
local(for (i in 1: 11) { 
  bpres <- (boxplot(mtcars[, i])$stats)
  print(bpres)
  bxp_list[[i]] <- bpres 
})

# Will cause an error
bpres
i


# Improving your code
for (i in seq_along(mtcars)) { 
  bpres <- (boxplot(mtcars[, i])$stats)
  print(bpres)
  bxp_list[[i]] <- bpres 
}

# Enclose for loop in a function
calc_bp <- function(dataset) {
  bxp_list <- vector(mode = "list", length = length(dataset))
  for (i in seq_along(dataset)) {
    bpres <- (boxplot(dataset[, i])$stats)
    print(bpres)
    bxp_list[[i]] <- bpres
  }
  return(bxp_list)
}

calc_bp(mtcars)
calc_bp(iris[,-5])

iris_bp <- calc_bp(iris[,-5])


# Advanced exercises

# Import weekly_sales.csv

library(readr)
weekly_sales <- read_csv("weekly_sales.csv")

# Plot the weekly sales for large soup.
library(lubridate)
plot(mdy(weekly_sales$Date[weekly_sales$Description 
                           == "LARGE SOUP"]), 
     weekly_sales$Sold[weekly_sales$Description 
                       == "LARGE SOUP"])

# Plot the weekly sales for large soup for store number 2.
with(weekly_sales, {
  plot(mdy(Date[Description == "LARGE SOUP" 
                & Store_num == 2]),
       Sold[Description == "LARGE SOUP" 
            & Store_num ==2])
})

# Make it a line chart and add some axis labels.
with(weekly_sales, {
  plot(mdy(Date[Description == "LARGE SOUP" 
                & Store_num == 2]),
       Sold[Description == "LARGE SOUP" 
            & Store_num ==2], 
       type = "l",
       xlab = "Date", ylab = "Soup Sales")
})

# Use a loop to add lines representing sales of large soup 
# for each of the other stores.

# create a vector containing the store numbers to loop over
strN <- unique(weekly_sales$Store_num)
# loop over each store number
for(i in strN) {
  # if this is the first store, we need to plot the data
  if(i == min(strN)){
    # colr sets the colour of the line
    colr <- 1
    with(weekly_sales, {
      plot(mdy(Date[Description == "LARGE SOUP" & 
                      Store_num == 2]),
           Sold[Description == "LARGE SOUP" & 
                  Store_num ==2], 
           type = "l",
           xlab = "Date", ylab = "Soup Sales")
    })
  } else {
    # if this is not the first store, add lines to existing plot
    with(weekly_sales, {
      lines(mdy(Date[Description == "LARGE SOUP" &
                       Store_num == i]),
            Sold[Description == "LARGE SOUP" &
                   Store_num ==i], col = colr)
    }) 
  }
  colr <- colr + 1
}  

# Plot weekly sales for large soup in separate charts for each store
for(i in strN) {
  if (i == min(strN)) par(mfrow = c(3,4), mar = c(4,3,2,1))
  with(weekly_sales, {
    plot(mdy(Date[Description == "LARGE SOUP" &
                    Store_num == i]),
         Sold[Description == "LARGE SOUP" &
                Store_num ==i], type = "b",
         xlab = "Date", ylab = "Soup Sales", 
         xlim = range(mdy(Date[Description == "LARGE SOUP"])),
         ylim = range(Sold[Description == "LARGE SOUP"]),
         main = paste("Sales for Store", i))
  })
}

# Plot weekly sales for each store for each item in its own chart
descN <- unique(weekly_sales$Description)

for(j in descN) {
  for(i in strN) {
    if (i == min(strN)) {
      plot.new()
      par(mfrow = c(3,4), mar = c(1,2,4,1))
    }
    with(weekly_sales, {
      plot(mdy(Date[Description == j &
                      Store_num == i]),
           Sold[Description == j &
                  Store_num ==i], type = "b", 
           xlab = "Date", ylab = "Sales", 
           xlim = range(mdy(Date[Description == j])),
           ylim = range(Sold[Description == j]),
           main = paste("Sales for Store", i))
    })
    mtext(paste(j, "Sales"), outer=TRUE,  cex=0.8, line=-1.5) 
  }
}

# Turn this into a function
plotSales <- function(dfsales){
  descN <- unique(dfsales$Description)
  strN <- unique(dfsales$Store_num)
  for(j in descN) {
    for(i in strN) {
      if (i == min(strN)) {
        plot.new()
        par(mfrow = c(3,4), mar = c(1,2,4,1))
      }
      with(dfsales, {
        plot(mdy(Date[Description == j &
                        Store_num == i]),
             Sold[Description == j &
                    Store_num ==i], type = "b", 
             xlab = "Date", ylab = "Sales", 
             xlim = range(mdy(Date[Description == j])),
             ylim = range(Sold[Description == j]),
             main = paste("Sales for Store", i))
      })
      mtext(paste(j, "Sales"), outer=TRUE,  cex=0.8, line=-1.5) 
    }
  }
}

plotSales(weekly_sales)

# while loops
x <- 10
counter <- 0
while(x >= 0) {
  print(sqrt(x))
  counter <- counter + 1
  x <- x-2
}

# Save results
whileRes <- vector(mode = "double", length = 21)
x <- 10
counter <- 0
print(counter)
while(x >= 0) {
  print(sqrt(x))
  counter <- counter + 1
  whileRes[counter] <- sqrt(x)
  x<-x-2
}

# fit a series of linear models to our soup data for store 14.
# create a subset of the data
library(tidyverse)
soupData <- filter(weekly_sales, 
                   Description == "LARGE SOUP" & 
                     Store_num == 14)
soupData$Date <- mdy(soupData$Date)

graphics.off()
# plot
with(soupData, {
  plot(Date, Sold)
})

# create a vector to store results
rSq <- vector(mode = "double", length = 10)
i <- 2

rSq[1] <- -1
# create the first model (a straight line)
soupMod <- lm(Sold ~ poly(Date, i - 1), data = soupData)  
ssMod <- summary(soupMod)
rSq[i] <- ssMod$adj.r.squared
# run the while loop – a recursive loop that increases the 
# degree of the polynomial only if the last increase 
# resulted in an increase in the adj-R-squared value 
while (rSq[i] > rSq[i-1]) {
  soupMod <- lm(Sold ~ poly(Date,  i ), data = soupData)
  ssMod <- summary(soupMod)
  rSq[i + 1] <- ssMod$adj.r.squared
  i <- i + 1
}
which.max(rSq)
# plot the fitted values for the model with the largest
# adj-R-squared
lines(soupData$Date, lm(Sold ~ poly(Date, which.max(rSq) - 1), data = soupData)$fitted)


# repeat loops
x <- 10
repeat { print(x)
  x <- x-1
  if(x < 0) { break }
}

# Rewrite the linear model loop above using a repeat loop
rSq <- vector(mode = "double", length = 10)
i <- 1
soupMod <- lm(Sold ~ poly(Date, i), data = soupData)  

i <- 2
repeat {
  soupMod <- lm(Sold ~ poly(Date, i), data = soupData)  
  ssMod <- summary(soupMod)
  rSq[i] <- ssMod$adj.r.squared
  if (rSq[i] <= rSq[i-1]) { break }
  i <- i + 1
}

which.max(rSq)
lines(soupData$Date, 
      lm(Sold ~ poly(Date, which.max(rSq)), 
         data = soupData)$fitted)


# Loop alternatives
jk <- lapply(mtcars, boxplot)
jk$mpg$stats

jk <- lapply(mtcars, boxplot, horizontal = TRUE)
jk$mpg$stats

myBp <- function(bpData) {
  res <- boxplot(bpData, horizontal = TRUE, xlab = names(bpData))
  mtext("mtcars Distributions", outer=TRUE,  cex=0.8, line=-1.5)
  return(res)
}

jk2 <- lapply(mtcars, myBp)
jk2$mpg$stats

# mapply
mapply(rep, 1:4, 4:1)

myBp <- function(bpData, ol) {
  res <- boxplot(bpData, horizontal = ol)
  return(res)
}

mapply(myBp, ol = c(TRUE, FALSE), rep(mtcars,2))

par(mfrow = c(1,3))
irisnm <- names(iris[2:4])
mapply(plot, x= iris[1], y=iris[2:4], ylab = irisnm, 
       xlab = "Sepal Length")

# tapply
tapply(iris$Petal.Length, iris$Species, range)
tapply(iris$Petal.Length, iris$Species, boxplot)

# split
sIris <- split(iris, iris$Species)
lapply(sIris, function(sI)(plot(sI$Petal.Length,
              sI$Petal.Width, main = unique(sI$Species))))

lapply(sIris,
       function(sI)(mean(sI$Petal.Length/sI$Petal.Width)))

# A more complex split / apply example

food_supply <- read_csv("food-supply-vs-life-expectancy.csv")

names(food_supply)[4:6] <- Cs(dailyEnergy, 
                              lifeExpect, population)
food_supply <- drop_na(food_supply, population)

graphics.off()
with(food_supply, { plot(Year[Entity == "Australia"], 
                         population[Entity == "Australia"])})

plotPop <- function(pD) {
  plot(pD$Year, 
       pD$population/1000000,
       xlab = "Year", ylab = "Population (millions)")
  mtext(pD$Entity, side =3, line = -1.5, outer=TRUE)
  return(mean(pD$population)) 
}

plotPop(food_supply[food_supply$Entity == "Australia",])

fss <- split(food_supply, food_supply$Entity)

lapply(fss, plotPop)

lapply(fss, function(pD) c(mean(pD$population), 
                             min(pD$Year), max(pD$Year)))

# map
map(mtcars, range)
map(sIris, ~lm(Petal.Length ~ Petal.Width, data = .))
map(fss, plotPop)

map_if(iris, is.numeric, range)

map(mtcars, min)

map_dbl(mtcars, min)


# walk
plotPopT <- function(pD) {
  plot(pD$Year, pD$population/1000000,
       xlab = "Year", ylab = "Population (millions)")
  mtext(pD$Entity, side =3, line = -1.5, outer=TRUE)
}

map(fss, plotPopT)
walk(fss, plotPopT)

plotPopT <- function(pD, plotN) {
  bmp(plotN)
  plot(pD$Year, pD$population/1000000,
       xlab = "Year", ylab = "Population (millions)")
  mtext(pD$Entity, side =3, line = -1.5, outer=TRUE)
  dev.off()
}

dir.create("CountryPlots")
plotNames <- file.path(paste0("CountryPlots\\",
                              names(fss),".bmp"))
walk2(fss, plotNames, plotPopT)


# split on multiple factors
stDe <- interaction(weekly_sales$Store_num, 
                    weekly_sales$Description, drop = TRUE)

spSales <- split(weekly_sales, stDe)

walk(spSales, ~ if(length(.x$Date) > 1) plot(mdy(.x$Date),
                  .x$Sold, xlab = "Date", ylab = "Sold", 
                  main = paste("Store", min(.x$Store_num), "-",
                  min(.x$Description))))

# piping
library(magrittr) 

iris %>% 
  group_by(Species) %>% 
  summarise(Mean = mean(Petal.Length))

iris_summ <- iris %>% 
  group_by(Species) %>% 
  summarise(mean = mean(Petal.Length))

iris_summ <- iris %>% 
  group_by(Species) %>% 
  summarise(mean = mean(Petal.Length)) %>%
  print


# Manipulate data with pipes
manip_ws <- weekly_sales %>%
  arrange(-Price, Unit_Cost) %>%
  mutate(lDate = mdy(Date)) %>%
  mutate(Month = month(lDate), Day=day(lDate), 
         Weekday = wday(lDate)) %>%
  mutate(Profit = Sales - Cost, Margin = Profit/Sales) %>%
  mutate(Chicken = str_detect(Description, "CHICKEN"), 
         Bacon = str_detect(Description, "BACON")) %>%
  select(INV_NUMBER, Store_num, Description, Chicken, Bacon, 
         everything()) %>%
  select(-Date) %>%
  mutate(Chicken = ifelse(Chicken, "chick",""), 
         Bacon = ifelse(Bacon, "bac","")) %>%
  mutate(Category = paste0(Chicken, Bacon))

iris %T>% 
  with(plot(Petal.Width, Petal.Length)) %>% 
  summarise(mean = mean(Petal.Length))

iris %>% 
  arrange(Petal.Length) %$%
  plot(Petal.Width, Petal.Length)

# ggplot
ggplot(data = iris, 
       mapping = aes(Petal.Width, Petal.Length))

ggplot(data = iris, 
       mapping = aes(Petal.Width, Petal.Length)) +
  geom_point()

ggplot(data = iris, 
       mapping = aes(Petal.Width, Petal.Length)) +
  geom_point(colour = 3)

ggplot(data = iris, 
       mapping = aes(Petal.Width, Petal.Length, 
                     colour = Species)) +
  geom_point()


ggplot(data = iris, 
       mapping = aes(Petal.Width, Petal.Length, 
                     colour = Species)) +
  geom_point(aes(shape = Species))


iris_gp <- ggplot(data = iris, 
                  mapping = aes(Petal.Width, Petal.Length, 
                                colour = Species)) +
  geom_point(aes(shape = Species))

iris_gp

iris_gp2 <- iris_gp + 
  labs(x = "Petal.Width", y = " Petal Length", 
       title = "Iris Dataset", 
       subtitle = "Petal Measurements")

iris_gp3 <- iris_gp2 +
  theme_classic() +
  theme(legend.position = "bottom", 
        legend.direction = "horizontal")

iris_gp4 <- iris_gp3 + 
  scale_colour_brewer(type = "qual", palette = "Paired")

ggsave("Iris.jpg")


# ggplot line chart
ggplot(food_supply) + 
  geom_point(mapping = aes(Year, population))

food_sup_sub <- filter(food_supply, 
                       Entity %in% 
                         Cs(Australia, Singapore, 
                            Netherlands, Canada,
                            France, Italy, Finland))

ggplot(data = food_sup_sub) +
  geom_point(mapping = aes(Year, population, colour = Entity))


ggplot(data = food_sup_sub) +
  geom_point(mapping = 
               aes(Year, population, colour = Entity)) +
  geom_line(mapping = 
              aes(Year, population, colour = Entity))

ggplot(data = food_sup_sub, 
       mapping = aes(Year, population, colour = Entity)) +
  geom_point() +
  geom_line()

ggplot(data = food_sup_sub, 
       mapping = aes(Year, population/1000000
                     , colour = Entity)) +
  geom_line()

ggplot(data = food_sup_sub, 
       mapping = aes(Year, population/1000000
                     , colour = Entity)) +
  geom_line() +
  labs(y = "Population (Millions)", 
       title = "Population over Time")


# facet_wrap
ggplot(data = food_sup_sub, 
       mapping = aes(Year, population/1000000,
                     colour = Entity)) +
  geom_line() +
  labs(y = "Population (Millions)", 
       title = "Population over Time") +
  facet_wrap(~Entity)

soupSub <- weekly_sales[weekly_sales$Description == "LARGE SOUP",]
ggplot(data = soupSub) +
  geom_line(mapping = aes(x = mdy(Date), y = Sold)) +
  labs(x = "Month", title = "Store Sales",
       subtitle = "Large Soup") +
  facet_wrap(~ Store_num)

splitSales <- split(weekly_sales, weekly_sales$Description)

salesPlot <- function(dta) {
  ggplot(data = dta) +
    geom_line(mapping = aes(x = mdy(Date), y = Sold)) +
    labs(x = "Month", title = "Store Sales",
         subtitle = dta$Description,
         x) +
    scale_y_continuous(n.breaks = 3)+
    facet_wrap(~ Store_num)
}

map(splitSales, salesPlot)

